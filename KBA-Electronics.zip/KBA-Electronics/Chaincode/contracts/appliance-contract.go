package contracts

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// ApplianceContract contract for managing CRUD for Appliance
type ApplianceContract struct {
	contractapi.Contract
}

type PaginatedQueryResult struct {
	Records             []*Appliance `json:"records"`
	FetchedRecordsCount int32  `json:"fetchedRecordsCount"`
	Bookmark            string `json:"bookmark"`
}

type HistoryQueryResult struct {
	Record    *Appliance   `json:"record"`
	TxId      string `json:"txId"`
	Timestamp string `json:"timestamp"`
	IsDelete  bool   `json:"isDelete"`
}

type Appliance struct {
	AssetType         string `json:"AssetType"`
	ApplianceId             string `json:"ApplianceId"`
	Color             string `json:"Color"`
	DateOfManufacture string `json:"DateOfManufacture"`
	OwnedBy           string `json:"OwnedBy"`
	Make              string `json:"Make"`
	Model             string `json:"Model"`
	Status            string `json:"Status"`
}

type EventData struct{
	Type string
	Model string
}

// ApplianceExists returns true when asset with given ID exists in world state
func (c *ApplianceContract) ApplianceExists(ctx contractapi.TransactionContextInterface, applianceID string) (bool, error) {
	data, err := ctx.GetStub().GetState(applianceID)

	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)

	}
	return data != nil, nil
}

// CreateAppliance creates a new instance of Appliance
func (c *ApplianceContract) CreateAppliance(ctx contractapi.TransactionContextInterface, applianceID string, make string, model string, color string, manufacturerName string, dateOfManufacture string) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	// if clientOrgID == "Org1MSP" {
	// if clientOrgID == "manufacturer-auto-com" {
	if clientOrgID == "ManufacturerMSP" {
		exists, err := c.ApplianceExists(ctx, applianceID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		} else if exists {
			return "", fmt.Errorf("the asset %s already exists", applianceID)
		}

		appliance := Appliance{
			AssetType:         "appliance",
			ApplianceId:             applianceID,
			Color:             color,
			DateOfManufacture: dateOfManufacture,
			Make:              make,
			Model:             model,
			OwnedBy:           manufacturerName,
			Status:            "In Factory",
		}
		fmt.Println("Create appliance data ======= ", appliance)
		bytes, _ := json.Marshal(appliance)

		err = ctx.GetStub().PutState(applianceID, bytes)
		if err != nil {
			return "", err
		} else {
			addApplianceEventData := EventData{
				Type: "Appliance creation",
				Model: model,
			}
			eventDataByte, _ := json.Marshal(addApplianceEventData)
			ctx.GetStub().SetEvent("CreateAppliance",eventDataByte)

			return fmt.Sprintf("successfully added appliance %v", applianceID), nil
		}

	} else {
		return "", fmt.Errorf("user under following MSPID: %v can't perform this action", clientOrgID)
	}

}

// ReadAppliance retrieves an instance of Appliance from the world state
func (c *ApplianceContract) ReadAppliance(ctx contractapi.TransactionContextInterface, applianceID string) (*Appliance, error) {
	exists, err := c.ApplianceExists(ctx, applianceID)
	if err != nil {
		return nil, fmt.Errorf("could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("the asset %s does not exist", applianceID)
	}

	bytes, _ := ctx.GetStub().GetState(applianceID)

	appliance := new(Appliance)

	err = json.Unmarshal(bytes, &appliance)

	if err != nil {
		return nil, fmt.Errorf("could not unmarshal world state data to type Appliance")
	}

	return appliance, nil
}

// DeleteAppliance removes the instance of Appliance from the world state
func (c *ApplianceContract) DeleteAppliance(ctx contractapi.TransactionContextInterface, applianceID string) (string, error) {

	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}
	// if clientOrgID == "Org1MSP" {
	// if clientOrgID == "manufacturer-auto-com" {
	if clientOrgID == "ManufacturerMSP" {
		exists, err := c.ApplianceExists(ctx, applianceID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		} else if !exists {
			return "", fmt.Errorf("the asset %s does not exist", applianceID)
		}

		err = ctx.GetStub().DelState(applianceID)
		if err != nil {
			return "", err
		} else {
			return fmt.Sprintf("appliance with id %v is deleted from the world state.", applianceID), nil
		}

	} else {
		return "", fmt.Errorf("user under following MSP:%v cannot able to perform this action", clientOrgID)
	}
}

// GetAppliancesByRange gives a range of asset details based on a start key and end key
func (c *ApplianceContract) GetAppliancesByRange(ctx contractapi.TransactionContextInterface, startKey, endKey string) ([]*Appliance, error) {
	resultsIterator, err := ctx.GetStub().GetStateByRange(startKey, endKey)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	return applianceResultIteratorFunction(resultsIterator)
}

func (c *ApplianceContract) GetApplianceHistory(ctx contractapi.TransactionContextInterface, applianceID string) ([]*HistoryQueryResult, error) {

	resultsIterator, err := ctx.GetStub().GetHistoryForKey(applianceID)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	var records []*HistoryQueryResult
	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var appliance Appliance
		if len(response.Value) > 0 {
			err = json.Unmarshal(response.Value, &appliance)
			if err != nil {
				return nil, err
			}
		} else {
			appliance = Appliance{
				ApplianceId: applianceID,
			}
		}

		timestamp := response.Timestamp.AsTime()

		formattedTime := timestamp.Format(time.RFC1123)

		record := HistoryQueryResult{
			TxId:      response.TxId,
			Timestamp: formattedTime,
			Record:    &appliance,
			IsDelete:  response.IsDelete,
		}
		records = append(records, &record)
	}

	return records, nil
}

func (c *ApplianceContract) GetAllAppliances(ctx contractapi.TransactionContextInterface) ([]*Appliance, error) {

	queryString := `{"selector":{"AssetType":"appliance"}, "sort":[{ "ApplianceId": "desc"}]}`

	resultsIterator, err := ctx.GetStub().GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()
	return applianceResultIteratorFunction(resultsIterator)
}

func (c *ApplianceContract) GetAppliancesWithPagination(ctx contractapi.TransactionContextInterface, pageSize int32, bookmark string) (*PaginatedQueryResult, error) {
	queryString := `{"selector":{"AssetType":"appliance"}}`
	resultsIterator, responseMetadata, err := ctx.GetStub().GetQueryResultWithPagination(queryString, pageSize, bookmark)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	appliances, err := applianceResultIteratorFunction(resultsIterator)
	if err != nil {
		return nil, err
	}

	return &PaginatedQueryResult{
		Records:             appliances,
		FetchedRecordsCount: responseMetadata.FetchedRecordsCount,
		Bookmark:            responseMetadata.Bookmark,
	}, nil
}

// Iterator function
func applianceResultIteratorFunction(resultsIterator shim.StateQueryIteratorInterface) ([]*Appliance, error) {
	var appliances []*Appliance
	for resultsIterator.HasNext() {
		queryResult, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		var appliance Appliance
		err = json.Unmarshal(queryResult.Value, &appliance)
		if err != nil {
			return nil, err
		}
		appliances = append(appliances, &appliance)
	}

	return appliances, nil
}

// GetMatchingOrders get matching orders for appliance from the orders
func (c *ApplianceContract) GetMatchingOrders(ctx contractapi.TransactionContextInterface, applianceID string) ([]*Order, error) {
	exists, err := c.ApplianceExists(ctx, applianceID)
	if err != nil {
		return nil, fmt.Errorf("could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("the asset %s does not exist", applianceID)
	}

	appliance, err := c.ReadAppliance(ctx, applianceID)
	if err != nil {
		return nil, fmt.Errorf("error reading appliance %v", err)
	}
	queryString := fmt.Sprintf(`{"selector":{"assetType":"Order","make":"%s", "model": "%s", "color":"%s"}}`, appliance.Make, appliance.Model, appliance.Color)
	resultsIterator, err := ctx.GetStub().GetPrivateDataQueryResult(collectionName, queryString)

	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	return OrderResultIteratorFunction(resultsIterator)

}

// MatchOrder matches appliance with matching order
func (c *ApplianceContract) MatchOrder(ctx contractapi.TransactionContextInterface, applianceID string, orderID string) (string, error) {

	bytes, err := ctx.GetStub().GetPrivateData(collectionName, orderID)
	if err != nil {
		fmt.Println("Could not get ptivate data")
	}
	order := new(Order)

	err = json.Unmarshal(bytes, order)

	if err != nil {
		fmt.Println("Could not get ptivate data")
	}

	if err != nil {
		return "", err
	}

	appliance, err := c.ReadAppliance(ctx, applianceID)
	if err != nil {
		return "", err
	}

	if appliance.Make == order.Make && appliance.Color == order.Color && appliance.Model == order.Model {
		appliance.OwnedBy = order.EcomName
		appliance.Status = "assigned to a ecom"
		bytes, _ := json.Marshal(appliance)
		ctx.GetStub().DelPrivateData(collectionName, orderID)
		err = ctx.GetStub().PutState(applianceID, bytes)
		if err != nil {
			return "", err
		} else {
			return fmt.Sprintf("Deleted order %v and Assigned %v to %v", orderID, appliance.ApplianceId, order.EcomName), nil
		}
	} else {
		return "", fmt.Errorf("order is not matching")
	}
}

// RegisterAppliance register appliance to the buyer
func (c *ApplianceContract) RegisterAppliance(ctx contractapi.TransactionContextInterface, applianceID string, ownerName string, registrationNumber string) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	// if clientOrgID == "Org3MSP" {
	// if clientOrgID == "mvd-auto-com" {
	if clientOrgID == "DeliveryMSP" {

		exists, err := c.ApplianceExists(ctx, applianceID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		}
		if exists {
			appliance, _ := c.ReadAppliance(ctx, applianceID)
			appliance.Status = fmt.Sprintf("Registered to  %v with plate number %v", ownerName, registrationNumber)
			appliance.OwnedBy = ownerName

			bytes, _ := json.Marshal(appliance)
			err = ctx.GetStub().PutState(applianceID, bytes)
			if err != nil {
				return "", err
			} else {
				return fmt.Sprintf("Appliance %v successfully registered to %v", applianceID, ownerName), nil
			}

		} else {
			return "", fmt.Errorf("appliance %v does not exist", applianceID)
		}

	} else {
		return "", fmt.Errorf("user under following MSPID: %v cannot able to perform this action", clientOrgID)
	}

}

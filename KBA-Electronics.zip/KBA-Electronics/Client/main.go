package main

import "fmt"

func main() {

	// use this functions to evaluate and submit txns
	// try calling these functions

	// result := submitTxnFn(
	// 	"manufacturer",
	// 	"electronicschannel",
	// 	"KBA-Electronics",
	// 	"ApplianceContract",
	// 	"invoke",
	// 	make(map[string][]byte),
	// 	"CreateAppliance",
	// 	"JBL",
	// 	"HeadSet",
	// 	"JBL1",
	// 	"BLACK",
	// 	"HYDFPC1",
	// 	"10/04/2022",
	// )

	// privateData := map[string][]byte{
	// 	"make":       []byte("Sam"),
	// 	"model":      []byte("One1"),
	// 	"color":      []byte("BLUE"),
	// 	"ecomName": []byte("Popular"),
	// }

	//result := submitTxnFn("ecom", "electronicschannel", "KBA-Electronics", "OrderContract", "private", privateData, "CreateOrder", "One1")
	 //result := submitTxnFn("ecom", "electronicschannel", "KBA-Electronics", "OrderContract", "query", make(map[string][]byte), "ReadOrder", "ORD4")
	// result := submitTxnFn("manufacturer", "electronicschannel", "KBA-Electronics", "ApplianceContract", "query", make(map[string][]byte), "GetAllAppliances")
	//result := submitTxnFn("manufacturer", "electronicschannel", "KBA-Electronics", "OrderContract", "query", make(map[string][]byte), "GetAllOrders")
	//no result
	//result := submitTxnFn("manufacturer", "electronicschannel", "KBA-Electronics", "ApplianceContract", "query", make(map[string][]byte), "GetMatchingOrders", "appliance")
	//no result
	//result := submitTxnFn("manufacturer", "electronicschannel", "KBA-Electronics", "ApplianceContract", "invoke", make(map[string][]byte), "MatchOrder", "samsung", "ss1")
	// result := submitTxnFn("delivery", "electronicschannel", "KBA-Electronics", "ApplianceContract", "invoke", make(map[string][]byte), "RegisterAppliance", "Oneplus", "Yakoob", "OnlineOrd")
	fmt.Println(result)
}

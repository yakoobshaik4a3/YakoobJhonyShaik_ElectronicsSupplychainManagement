package main

func main() {

	// blockEventListener("manufacturer", "electronicschannel")
	chaincodeEventListener("manufacturer", "electronicschannel", "KBA-Electronics")
	// pvtBlockEventListener("manufacturer", "electronicschannel")

}
package main

import (
	"fmt"
	"net/http"
	"sync"

	"github.com/gin-gonic/gin"
)

type Appliance struct {
	ApplianceId        string `json:"aplianceId"`
	Make         string `json:"make"`
	Model        string `json:"model"`
	Color        string `json:"color"`
	Date         string `json:"dateOfManufacture"`
	Manufacturer string `json:"manufacturerName"`
}

func main() {
	router := gin.Default()

	var wg sync.WaitGroup
	wg.Add(1)
	go ChaincodeEventListener("manufacturer", "electronicschannel", "KBA-Electronics", &wg)

	router.Static("/public", "./public")
	router.LoadHTMLGlob("templates/*")

	router.GET("/", func(ctx *gin.Context) {
		ctx.HTML(http.StatusOK, "index.html", gin.H{
			"title": "Auto App",
		})
	})

	router.POST("/api/apliance", func(ctx *gin.Context) {
		var req Appliance
		if err := ctx.BindJSON(&req); err != nil {
			ctx.JSON(http.StatusBadRequest, gin.H{"message": "Bad request"})
			return
		}

		fmt.Printf("apliance response %s", req)
		emptyPvtData := make(map[string][]byte)
		submitTxnFn("manufacturer", "electronicschannel", "KBA-Electronics", "ApplianceContract", "invoke", emptyPvtData, "CreateAppliance", req.ApplianceId, req.Make, req.Model, req.Color, req.Manufacturer, req.Date)

		ctx.JSON(http.StatusOK, req)
	})

	router.GET("/api/apliance/:id", func(ctx *gin.Context) {
		aplianceId := ctx.Param("id")

		emptyPvtData := make(map[string][]byte)
		result := submitTxnFn("manufacturer", "electronicschannel", "KBA-Electronics", "ApplianceContract", "query", emptyPvtData, "ReadAppliance", aplianceId)

		ctx.JSON(http.StatusOK, gin.H{"data": result})
	})


	router.GET("/get-event", func(ctx *gin.Context) {
		result := getEvents()
		fmt.Println("result:", result)

		ctx.JSON(http.StatusOK, gin.H{"aplianceEvent": result})
	})

	router.Run("0.0.0.0:3000")
}